package com.example.companion

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import org.json.JSONArray
import org.json.JSONObject

/** Things Capri can DO on the phone. Claude picks these via tool use. */
object Tools {

    val schema: JSONArray = JSONArray()
        .put(tool("call_contact",
            "Place a phone call to a saved contact. Only use when the user clearly asked to call someone.",
            "name" to "Contact name as the user said it, e.g. Mom"))
        .put(tool("read_recent_messages",
            "Get the user's most recent incoming message notifications (sender, app, text)."))
        .put(tool("open_app",
            "Open an installed app by its name, e.g. TikTok, WhatsApp, Camera.",
            "name" to "App name"))

    private fun tool(name: String, desc: String, vararg params: Pair<String, String>): JSONObject {
        val props = JSONObject()
        val req = JSONArray()
        params.forEach { (k, d) ->
            props.put(k, JSONObject().put("type", "string").put("description", d))
            req.put(k)
        }
        return JSONObject().put("name", name).put("description", desc)
            .put("input_schema", JSONObject().put("type", "object").put("properties", props).put("required", req))
    }

    fun run(ctx: Context, name: String, input: JSONObject): String = when (name) {
        "call_contact" -> call(ctx, input.optString("name"))
        "read_recent_messages" -> messages()
        "open_app" -> openApp(ctx, input.optString("name"))
        else -> "Unknown tool: $name"
    }

    private fun granted(ctx: Context, p: String) =
        ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun call(ctx: Context, q: String): String {
        if (q.isBlank()) return "No name given."
        if (!granted(ctx, Manifest.permission.READ_CONTACTS))
            return "Contacts permission missing. Tell the user to grant it from the Capri app."
        if (!granted(ctx, Manifest.permission.CALL_PHONE))
            return "Phone permission missing. Tell the user to grant it from the Capri app."

        val hits = findContacts(ctx, q)
        if (hits.isEmpty()) return "No contact matching '$q'. Try a nickname or another spelling."
        val exact = hits.filter { it.first.equals(q, ignoreCase = true) }
        val pool = if (exact.isNotEmpty()) exact else hits
        val names = pool.map { it.first }.distinct()
        if (names.size > 1) return "Several contacts match: ${names.joinToString()}. Ask the user which one."

        val (contact, number) = pool.first()
        ctx.startActivity(
            Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return "Calling $contact now."
    }

    private fun findContacts(ctx: Context, q: String): List<Pair<String, String>> {
        val seen = LinkedHashMap<String, String>() // number -> name
        val phone = ContactsContract.CommonDataKinds.Phone
        ctx.contentResolver.query(
            phone.CONTENT_URI,
            arrayOf(phone.DISPLAY_NAME, phone.NUMBER),
            "${phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                val key = num.filter { it.isDigit() || it == '+' }
                if (key.isNotEmpty() && key !in seen) seen[key] = n
            }
        }
        return seen.map { it.value to it.key }
    }

    private fun messages(): String {
        if (!MessageListener.connected)
            return "Notification access is off. Tell the user to enable it from the Capri app."
        val items = MessageListener.snapshot()
        return if (items.isEmpty()) "No recent message notifications." else items.joinToString("\n")
    }

    @Suppress("DEPRECATION")
    private fun openApp(ctx: Context, q: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().equals(q, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(q, true) }
            ?: return "No app named '$q'."
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "That app can't be launched."
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened ${hit.loadLabel(pm)}."
    }
}

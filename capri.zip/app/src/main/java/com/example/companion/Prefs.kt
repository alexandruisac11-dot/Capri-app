package com.example.companion

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("capri", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("key", v.trim()).apply()

    fun voice(c: Context): String = sp(c).getString("voice", "") ?: ""
    fun setVoice(c: Context, v: String) = sp(c).edit().putString("voice", v).apply()

    fun pitch(c: Context): Float = sp(c).getFloat("pitch", 1.0f)
    fun setPitch(c: Context, v: Float) = sp(c).edit().putFloat("pitch", v).apply()
    fun rate(c: Context): Float = sp(c).getFloat("rate", 1.0f)
    fun setRate(c: Context, v: Float) = sp(c).edit().putFloat("rate", v).apply()

    fun flag(c: Context, k: String): Boolean = sp(c).getBoolean(k, false)
    fun setFlag(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun applyVoice(c: Context, tts: TextToSpeech) {
        tts.language = Locale.getDefault()
        val v = voice(c)
        if (v.isNotEmpty()) tts.voices?.firstOrNull { it.name == v }?.let { tts.voice = it }
        tts.setPitch(pitch(c))
        tts.setSpeechRate(rate(c))
    }
}

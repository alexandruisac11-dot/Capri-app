package com.example.companion

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Collects message-style notifications so Capri can read them to you. */
class MessageListener : NotificationListenerService() {

    override fun onListenerConnected() { connected = true }
    override fun onListenerDisconnected() { connected = false }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val cat = n.category
        if (cat != Notification.CATEGORY_MESSAGE && cat != Notification.CATEGORY_EMAIL &&
            cat != Notification.CATEGORY_SOCIAL) return

        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName }

        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(sbn.postTime))
        synchronized(buf) {
            buf.addLast("[$time] $app - $title: $text")
            while (buf.size > 30) buf.removeFirst()
        }
        onNew?.invoke(app, title, text)
    }

    companion object {
        @Volatile var connected = false
        @Volatile var onNew: ((String, String, String) -> Unit)? = null
        private val buf = ArrayDeque<String>()
        fun snapshot(): List<String> = synchronized(buf) { buf.toList() }
    }
}

package com.example.companion

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    private var tts: TextToSpeech? = null
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var chatLog: TextView
    private lateinit var voiceSpinner: Spinner

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (it[Manifest.permission.RECORD_AUDIO] == true) askScreenCapture()
            else toast("Microphone permission is required")
        }

    private val permOnlyLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            toast("Permissions updated")
        }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK && r.data != null) {
                val i = Intent(this, CompanionService::class.java)
                    .putExtra("code", r.resultCode)
                    .putExtra("data", r.data)
                startForegroundService(i)
                toast("Capri is on. Open any app and tap the bubble.")
                moveTaskToBack(true)
            } else toast("Screen capture was declined")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(40))
        }
        fun label(t: String, size: Float = 14f) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, dp(16), 0, dp(4))
        }.also { col.addView(it) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
        }.also { col.addView(it) }
        fun check(t: String, key: String) = CheckBox(this).apply {
            text = t; isChecked = Prefs.flag(this@MainActivity, key)
            setOnCheckedChangeListener { _, c -> Prefs.setFlag(this@MainActivity, key, c) }
        }.also { col.addView(it) }
        fun slider(name: String, get: () -> Float, set: (Float) -> Unit) {
            label(name)
            col.addView(SeekBar(this).apply {
                max = 150
                progress = (get() * 100 - 50).toInt().coerceIn(0, 150)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { set((p + 50) / 100f) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }

        label("Capri", 30f)

        label("1. API key (from console.anthropic.com)")
        val keyBox = EditText(this).apply {
            setText(Prefs.apiKey(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = "sk-ant-..."
        }
        col.addView(keyBox)
        btn("Save key") { Prefs.setApiKey(this, keyBox.text.toString()); toast("Saved") }

        label("2. Permissions")
        btn("Allow floating bubble") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Allow mic, contacts, calls") { permOnlyLauncher.launch(allPerms) }
        btn("Allow reading message notifications") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        label("3. Her voice")
        voiceSpinner = Spinner(this)
        col.addView(voiceSpinner)
        slider("Pitch", { Prefs.pitch(this) }, { Prefs.setPitch(this, it) })
        slider("Speed", { Prefs.rate(this) }, { Prefs.setRate(this, it) })
        btn("Test voice") {
            tts?.let {
                Prefs.applyVoice(this, it)
                it.speak("Hi, I'm Capri. How do I sound?", TextToSpeech.QUEUE_FLUSH, null, "test")
            }
        }
        check("Hands-free: listen again after she talks", "hands_free")
        check("Read incoming messages out loud", "announce")
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) runOnUiThread { fillVoices() }
        }

        label("4. Run")
        btn("Start Capri") {
            when {
                Prefs.apiKey(this).isBlank() -> toast("Save your API key first")
                !Settings.canDrawOverlays(this) -> toast("Allow the floating bubble first")
                else -> permLauncher.launch(allPerms)
            }
        }
        btn("Stop Capri") { stopService(Intent(this, CompanionService::class.java)) }

        label("Chat (text)")
        chatLog = TextView(this).apply { setTextIsSelectable(true); setPadding(0, dp(8), 0, dp(8)) }
        col.addView(chatLog)
        val input = EditText(this).apply { hint = "Type to Capri" }
        col.addView(input)
        btn("Send") {
            val t = input.text.toString().trim()
            if (t.isEmpty()) return@btn
            input.setText("")
            chatLog.text = Brain.transcript() + "\n\nYou: $t\n\n(thinking...)"
            io.execute {
                val err = try { Brain.ask(applicationContext, t, null); null } catch (e: Exception) { e.message }
                runOnUiThread {
                    chatLog.text = Brain.transcript() + (if (err != null) "\n\nError: $err" else "")
                }
            }
        }

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        chatLog.text = Brain.transcript()
    }

    private fun fillVoices() {
        val lang = Locale.getDefault().language
        val vs = (tts?.voices ?: emptySet()).filter { it.locale.language == lang }.sortedBy { it.name }
        val names = listOf("Default") + vs.map { it.name }
        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        voiceSpinner.setSelection(names.indexOf(Prefs.voice(this)).coerceAtLeast(0))
        voiceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Prefs.setVoice(this@MainActivity, if (pos == 0) "" else names[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private val allPerms = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.POST_NOTIFICATIONS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE
    )

    private fun askScreenCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        captureLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        tts?.shutdown(); io.shutdown()
        super.onDestroy()
    }
}

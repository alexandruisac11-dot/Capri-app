package com.example.companion

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.DateFormat
import java.util.Date

/** One shared conversation (voice, overlay text and in-app chat all use it). */
object Brain {
    // Change the model here if you want a different one.
    private const val MODEL = "claude-sonnet-5-5"

    private val history = mutableListOf<Pair<String, String>>()
    private val log = mutableListOf<String>()

    @Synchronized fun transcript(): String = log.joinToString("\n\n")

    private fun system() =
        "You are Capri, a warm, witty AI companion and assistant living on the user's Android phone. " +
        "Your replies are often spoken aloud, so keep them to 1-3 short sentences with no markdown or emojis. " +
        "When a screenshot is attached it shows what the user is looking at right now; react to it naturally if relevant. " +
        "The small round bubble in it is your own UI, ignore it. Don't read out private details (banking, passwords). " +
        "You have tools: call_contact (only when the user clearly asks to call someone), " +
        "read_recent_messages (when asked about messages or who texted), open_app. " +
        "Say briefly what you did after using a tool. Current time: ${DateFormat.getDateTimeInstance().format(Date())}."

    @Synchronized
    fun ask(ctx: Context, userText: String, jpeg: ByteArray?): String {
        val msgs = JSONArray()
        history.forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }

        val content = JSONArray()
        if (jpeg != null) {
            content.put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject().put("type", "base64")
                        .put("media_type", "image/jpeg")
                        .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
                )
            )
        }
        content.put(JSONObject().put("type", "text").put("text", userText))
        msgs.put(JSONObject().put("role", "user").put("content", content))

        for (step in 0 until 5) {
            val res = post(ctx, msgs)
            val blocks = res.getJSONArray("content")

            if (res.optString("stop_reason") == "tool_use") {
                msgs.put(JSONObject().put("role", "assistant").put("content", blocks))
                val results = JSONArray()
                for (i in 0 until blocks.length()) {
                    val b = blocks.getJSONObject(i)
                    if (b.optString("type") != "tool_use") continue
                    val out = try {
                        Tools.run(ctx, b.getString("name"), b.optJSONObject("input") ?: JSONObject())
                    } catch (e: Exception) { "Error: ${e.message}" }
                    results.put(
                        JSONObject().put("type", "tool_result")
                            .put("tool_use_id", b.getString("id")).put("content", out)
                    )
                }
                msgs.put(JSONObject().put("role", "user").put("content", results))
            } else {
                val sb = StringBuilder()
                for (i in 0 until blocks.length()) {
                    val b = blocks.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.getString("text"))
                }
                val reply = sb.toString().trim().ifEmpty { "Done." }
                history += "user" to userText
                history += "assistant" to reply
                while (history.size > 16) history.removeAt(0)
                log += "You: $userText"
                log += "Capri: $reply"
                while (log.size > 100) log.removeAt(0)
                return reply
            }
        }
        throw IOException("Too many tool steps")
    }

    private fun post(ctx: Context, msgs: JSONArray): JSONObject {
        val key = Prefs.apiKey(ctx)
        if (key.isBlank()) throw IOException("Add your API key in the Capri app first")

        val body = JSONObject()
            .put("model", MODEL).put("max_tokens", 400)
            .put("system", system()).put("tools", Tools.schema).put("messages", msgs)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"; conn.doOutput = true
        conn.connectTimeout = 15000; conn.readTimeout = 60000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val txt = (if (code in 200..299) conn.inputStream else conn.errorStream)
            .bufferedReader().use { it.readText() }
        if (code !in 200..299) throw IOException("API $code: ${txt.take(160)}")
        return JSONObject(txt)
    }
}

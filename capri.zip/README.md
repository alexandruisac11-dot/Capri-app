# Capri v0.2 (build it from your phone)

Voice + text AI companion that sees your screen, reads your message
notifications, opens apps and calls contacts ("Capri, call Mom").

## Build with no PC (GitHub does the building)
1. On your phone browser: github.com > New repository (public is fine, the API key is NOT in the code).
2. In the repo: Add file > Create new file. Name it exactly `.github/workflows/build.yml`
   (typing the slashes creates the folders). Paste the contents of build.yml. Commit.
3. Add file > Upload files > pick `capri.zip` (don't unzip it). Commit.
4. Open the Actions tab. A run called "Build Capri" starts (about 3-5 min). Wait for the green check.
5. Open the run > scroll to Artifacts > tap `capri-apk` to download.
6. In Samsung "My Files", extract the zip, tap `app-debug.apk`, allow "install unknown apps". Install.
7. If the build fails (red X), open the run, copy the red error text and send it to Claude.

## First run on the S22
1. Open Capri, paste your API key, Save.
2. Tap the permission buttons. For notifications: turn Capri ON in the list.
   If Android says "restricted setting": Settings > Apps > Capri > three dots > Allow restricted settings, then retry.
3. Pick a voice, tweak pitch/speed, Test voice.
4. Start Capri, accept screen sharing. Open TikTok.

## Using her
- Tap the bubble: talk. Hold the bubble: type. Drag: move it. Tap reply box: dismiss.
- "Capri, call Mom" / "who messaged me?" / "open YouTube" / "what do you think of this video?"
- Hands-free mode: she listens again after she answers.
- Bubble colors: purple idle, pink listening, yellow thinking.

## Notes
- Each message sends one screenshot to the API (small cost). Keep the API key private.
- Calls go out immediately when she is sure about the contact. If two contacts match, she asks.
- She only sees message notifications, not your full chats.
- Better voices: install "Speech Services by Google" and pick a voice in Capri.
